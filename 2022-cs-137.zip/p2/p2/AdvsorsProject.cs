﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace p2
{
    public partial class AdvsorsProject : Form
    {
        public AdvsorsProject()
        {
            InitializeComponent();
        }

        private void AdvsorsProject_Load(object sender, EventArgs e)
        {
            LoadProjectIDs();
            LoadAdvisorIDs();
        }
        private void LoadProjectIDs()
        {
            var con = Configuration.getInstance().getConnection();
            string selectProjectIDsQuery = "SELECT Id FROM Project";
            SqlCommand cmdSelectProjectIDs = new SqlCommand(selectProjectIDsQuery, con);
            SqlDataReader reader = cmdSelectProjectIDs.ExecuteReader();

            // Clear existing items in the ComboBox
            comboBoxproject.Items.Clear();
            //searchbox.Items.Clear();

            // Add each project ID to the ComboBox
            while (reader.Read())
            {
                comboBoxproject.Items.Add(reader["Id"].ToString());
               // searchbox.Items.Add(reader["Id"].ToString());

            }

            // Close the reader
            reader.Close();
        }

        private void LoadAdvisorIDs()
        {
            var con = Configuration.getInstance().getConnection();
            string selectAdvisorIDsQuery = "SELECT Id FROM Advisor";
            SqlCommand cmdSelectAdvisorIDs = new SqlCommand(selectAdvisorIDsQuery, con);
            SqlDataReader reader = cmdSelectAdvisorIDs.ExecuteReader();

            // Clear existing items in the ComboBox
            comboBoxadvisor.Items.Clear();

            // Add each advisor ID to the ComboBox
            while (reader.Read())
            {
                comboBoxadvisor.Items.Add(reader["Id"].ToString());
            }

            // Close the reader
            reader.Close();
        }
        private int GetAdvisorRoleID(string advisorRole)
        {
            var con = Configuration.getInstance().getConnection();
            string selectAdvisorRoleIDQuery = "SELECT Id FROM Lookup WHERE Value = @AdvisorRole AND Category = 'ADVISOR_ROLE'";
            SqlCommand cmdSelectAdvisorRoleID = new SqlCommand(selectAdvisorRoleIDQuery, con);
            cmdSelectAdvisorRoleID.Parameters.AddWithValue("@AdvisorRole", advisorRole);
            int advisorRoleID = Convert.ToInt32(cmdSelectAdvisorRoleID.ExecuteScalar());
            return advisorRoleID;
        }

        private void assign_Click(object sender, EventArgs e)
        {
            if (comboBoxproject.SelectedItem == null || comboBoxadvisor.SelectedItem == null || comboBoxrole.SelectedItem == null)
            {
                MessageBox.Show("Please select ProjectID, AdvisorID, and AdvisorRole.");
                return;
            }

            var con = Configuration.getInstance().getConnection();

            // Retrieve selected values from ComboBoxes
            int projectID = Convert.ToInt32(comboBoxproject.SelectedItem);
            int advisorID = Convert.ToInt32(comboBoxadvisor.SelectedItem);
            string advisorRole = comboBoxrole.SelectedItem.ToString();

            // Get the AdvisorRole ID from the Lookup table
            int advisorRoleID = GetAdvisorRoleID(advisorRole);

            // Insert data into the ProjectAdvisor table
            string insertProjectAdvisorQuery = "INSERT INTO ProjectAdvisor (ProjectId, AdvisorId, AdvisorRole, AssignmentDate) VALUES (@ProjectId, @AdvisorId, @AdvisorRoleID, @AssignmentDate)";
            SqlCommand cmdInsertProjectAdvisor = new SqlCommand(insertProjectAdvisorQuery, con);
            cmdInsertProjectAdvisor.Parameters.AddWithValue("@ProjectId", projectID);
            cmdInsertProjectAdvisor.Parameters.AddWithValue("@AdvisorId", advisorID);
            cmdInsertProjectAdvisor.Parameters.AddWithValue("@AdvisorRoleID", advisorRoleID);
            cmdInsertProjectAdvisor.Parameters.AddWithValue("@AssignmentDate", DateTime.Now);

            // Execute the query
            cmdInsertProjectAdvisor.ExecuteNonQuery();

            MessageBox.Show("Project Advisor added successfully!");
            displaydata();
        }
        private void displaydata()
        {
            try
            {
                var con = Configuration.getInstance().getConnection();


                SqlCommand cmd = new SqlCommand("SELECT * FROM [ProjectAdvisor]", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView3.DataSource = dt;
                // The using statement will automatically close the connection
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }
    }
}
