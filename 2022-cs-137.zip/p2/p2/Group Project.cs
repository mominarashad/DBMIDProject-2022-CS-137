﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace p2
{
    public partial class Group_Project : Form
    {
        private int groupId;
        private int projectId;
        List<Tuple<string, string>> ProjectIds = new List<Tuple<string, string>>();
        public Group_Project()
        {
            InitializeComponent();
            getGroupids();
            getProjectids();
            getNewProjectids();
        }

        private void Group_Project_Load(object sender, EventArgs e)
        {

        }

        private void getGroupids()
        {
            try
            {
                var con = Configuration.getInstance().getConnection();

                using (SqlCommand command = new SqlCommand("Select Id FROM [Group]", con))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        comboBox1.Items.Clear();
                        while (reader.Read())
                        {
                            comboBox1.Items.Add(reader["Id"].ToString());
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading ids:" + ex.Message);
            }
        }

        private void getProjectids()
        {
            try
            {
                var con = Configuration.getInstance().getConnection();

                using (SqlCommand command = new SqlCommand("Select Id FROM [Project]", con))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        comboBox2.Items.Clear();
                        while (reader.Read())
                        {
                            comboBox2.Items.Add(reader["Id"].ToString());
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading ids:" + ex.Message);
            }
        }

        private void getNewProjectids()
        {
            try
            {
                var con = Configuration.getInstance().getConnection();

                using (SqlCommand command = new SqlCommand("Select Id FROM [Project]", con))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        comboBox3.Items.Clear();
                        while (reader.Read())
                        {
                            comboBox3.Items.Add(reader["Id"].ToString());
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading ids:" + ex.Message);
            }
        }

        private int CountGroups(int ProjectId)
        {
            int count = 0;
            try
            {
                var con = Configuration.getInstance().getConnection();
                string query = $"SELECT COUNT(*) FROM GroupProject WHERE ProjectId = {projectId}";
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    count = (int)command.ExecuteScalar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return count;
        }

        //private void addGroupProject(int groupId, int projectId)
        //{
        //    try
        //    {
        //        var con = Configuration.getInstance().getConnection();

        //        using (SqlCommand command = new SqlCommand("INSERT INTO [GroupProject] ( ProjectId,GroupId, AssignmentDate) VALUES ( @ProjectId,@GroupId, @AssignmentDate)", con))
        //        {
                    
        //            command.Parameters.AddWithValue("@ProjectId", projectId);
        //            command.Parameters.AddWithValue("@GroupId", groupId);
        //            command.Parameters.AddWithValue("@AssignmentDate", DateTime.Now);

        //            command.ExecuteNonQuery();
        //        }

        //        MessageBox.Show("Group-Project assignment added successfully.");
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error adding group-project assignment: " + ex.Message);
        //    }
        //}

        private void button3_Click(object sender, EventArgs e)
        {
            //addGroupProject(groupId, projectId);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selectedProjectId = comboBox2.SelectedItem?.ToString();
            string selectedGroupId = comboBox1.SelectedItem?.ToString();

            // Check both ids are selected
            if (!string.IsNullOrEmpty(selectedGroupId) && !string.IsNullOrEmpty(selectedProjectId))
            {
                // Call the modified addGroupProject method
                addGroupProject(Convert.ToInt32(selectedGroupId), Convert.ToInt32(selectedProjectId));
            }
            else
            {
                MessageBox.Show("Select both group and project ids");
            }
        }
        private void View_Click(object sender, EventArgs e)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();


                SqlCommand cmd = new SqlCommand("SELECT * FROM [GroupProject]", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView3.DataSource = dt;
                // The using statement will automatically close the connection
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }



        private bool IsProjectAssignedToGroup(SqlConnection connection, int projectId)
        {
            string query = "SELECT COUNT(*) FROM GroupProject WHERE ProjectId = @ProjectId";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@ProjectId", projectId);

                int count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }

        private bool IsGroupAssignedToProject(SqlConnection connection, int groupId)
        {
            string query = "SELECT COUNT(*) FROM GroupProject WHERE GroupId = @GroupId";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@GroupId", groupId);

                int count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }

        private void addGroupProject(int groupId, int projectId)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();

                // Check if the project is already assigned to a group
                if (IsProjectAssignedToGroup(con, projectId))
                {
                    MessageBox.Show("Project is already assigned to a group.");
                    return;
                }

                // Check if the group is already assigned to a project
                if (IsGroupAssignedToProject(con, groupId))
                {
                    MessageBox.Show("Group is already assigned to a project.");
                    return;
                }

                // If the project and group are not assigned, proceed with the assignment
                using (SqlCommand command = new SqlCommand("INSERT INTO [GroupProject] (ProjectId, GroupId, AssignmentDate) VALUES (@ProjectId, @GroupId, @AssignmentDate)", con))
                {
                    command.Parameters.AddWithValue("@ProjectId", projectId);
                    command.Parameters.AddWithValue("@GroupId", groupId);
                    command.Parameters.AddWithValue("@AssignmentDate", DateTime.Now);

                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Group-Project assignment added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding group-project assignment: " + ex.Message);
            }
        }
        private void updateGroupForProject(int projectId, int newGroupId)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();

                // Check if the project ID exists
                if (!IsProjectAssignedToGroup(con, projectId))
                {
                    MessageBox.Show("Project ID does not exist or is not assigned to any group.");
                    return;
                }

                // Update the group ID for the specified project
                using (SqlCommand command = new SqlCommand("UPDATE [GroupProject] SET GroupId = @NewGroupId WHERE ProjectId = @ProjectId", con))
                {
                    command.Parameters.AddWithValue("@NewGroupId", newGroupId);
                    command.Parameters.AddWithValue("@ProjectId", projectId);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Group ID updated successfully for the specified project.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to update group ID for the specified project.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating group ID: " + ex.Message);
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            string selectedProjectIdToUpdate = comboBox2.SelectedItem?.ToString();
            string newGroupId = comboBox3.SelectedItem?.ToString();

            // Check both project ID to update and new group ID are selected
            if (!string.IsNullOrEmpty(selectedProjectIdToUpdate) && !string.IsNullOrEmpty(newGroupId))
            {
                updateGroupForProject(Convert.ToInt32(selectedProjectIdToUpdate), Convert.ToInt32(newGroupId));
            }
            else
            {
                MessageBox.Show("Select both project ID to update and new group ID");
            }
        }


        //private void button3_Click(object sender, EventArgs e)
        //{

        //}


    }
}

