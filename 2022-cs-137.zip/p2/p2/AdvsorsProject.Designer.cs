﻿namespace p2
{
    partial class AdvsorsProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxrole = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.View = new System.Windows.Forms.Button();
            this.comboBoxadvisor = new System.Windows.Forms.ComboBox();
            this.comboBoxproject = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.assign = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(309, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 48);
            this.label6.TabIndex = 116;
            this.label6.Text = "Select  Advisor Role\r\n\r\n\r\n";
            // 
            // comboBoxrole
            // 
            this.comboBoxrole.FormattingEnabled = true;
            this.comboBoxrole.Items.AddRange(new object[] {
            "Main Advisor",
            "Co-Advisror",
            "Industry Advisor"});
            this.comboBoxrole.Location = new System.Drawing.Point(453, 73);
            this.comboBoxrole.Name = "comboBoxrole";
            this.comboBoxrole.Size = new System.Drawing.Size(245, 21);
            this.comboBoxrole.TabIndex = 115;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 307);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 13);
            this.label7.TabIndex = 114;
            this.label7.Text = "Enter GroupId to Update";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(135, 304);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(144, 20);
            this.textBox1.TabIndex = 113;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(318, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 16);
            this.label5.TabIndex = 112;
            this.label5.Text = "Select project Id\r\n";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(9, 352);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(270, 83);
            this.button2.TabIndex = 111;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // View
            // 
            this.View.Location = new System.Drawing.Point(9, 121);
            this.View.Name = "View";
            this.View.Size = new System.Drawing.Size(270, 83);
            this.View.TabIndex = 110;
            this.View.Text = "View";
            this.View.UseVisualStyleBackColor = true;
            // 
            // comboBoxadvisor
            // 
            this.comboBoxadvisor.FormattingEnabled = true;
            this.comboBoxadvisor.Location = new System.Drawing.Point(453, 2);
            this.comboBoxadvisor.Name = "comboBoxadvisor";
            this.comboBoxadvisor.Size = new System.Drawing.Size(252, 21);
            this.comboBoxadvisor.TabIndex = 109;
            // 
            // comboBoxproject
            // 
            this.comboBoxproject.FormattingEnabled = true;
            this.comboBoxproject.Location = new System.Drawing.Point(453, 34);
            this.comboBoxproject.Name = "comboBoxproject";
            this.comboBoxproject.Size = new System.Drawing.Size(252, 21);
            this.comboBoxproject.TabIndex = 108;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(318, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 32);
            this.label2.TabIndex = 107;
            this.label2.Text = "Select Advisor Id\r\n\r\n";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView3.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView3.Location = new System.Drawing.Point(302, 108);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(493, 341);
            this.dataGridView3.TabIndex = 106;
            this.dataGridView3.UseWaitCursor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(95, 243);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 105;
            // 
            // assign
            // 
            this.assign.Location = new System.Drawing.Point(9, 16);
            this.assign.Name = "assign";
            this.assign.Size = new System.Drawing.Size(270, 78);
            this.assign.TabIndex = 104;
            this.assign.Text = "Create Group";
            this.assign.UseVisualStyleBackColor = true;
            this.assign.Click += new System.EventHandler(this.assign_Click);
            // 
            // AdvsorsProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBoxrole);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.View);
            this.Controls.Add(this.comboBoxadvisor);
            this.Controls.Add(this.comboBoxproject);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.assign);
            this.Name = "AdvsorsProject";
            this.Text = "AdvsorsProject";
            this.Load += new System.EventHandler(this.AdvsorsProject_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxrole;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button View;
        private System.Windows.Forms.ComboBox comboBoxadvisor;
        private System.Windows.Forms.ComboBox comboBoxproject;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button assign;
    }
}