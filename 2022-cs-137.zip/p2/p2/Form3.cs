﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.VisualStyles;
namespace p2
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private int selectedGroupId = -1;
        private List<int> selectedStudentIds;
        private void button1_Click(object sender, EventArgs e)
        {
            string createdOn = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            // Insert the new group into the database
            InsertNewGroup(createdOn);
        }
        private void InsertNewGroup(string createdOn)
        {
            try
            {
                using (SqlConnection connection = Configuration.getInstance().getConnection())
                {
                    connection.Open(); // Open the connection explicitly

                    // Step 1: Insert data into the Group table
                    string insertGroupQuery = "INSERT INTO [Group] (Created_On) VALUES (@CreatedOn); SELECT SCOPE_IDENTITY();";
                    SqlCommand cmdInsertGroup = new SqlCommand(insertGroupQuery, connection);
                    cmdInsertGroup.Parameters.AddWithValue("@CreatedOn", createdOn);

                    // Retrieve the auto-generated ID of the newly inserted group
                    int newGroupId = Convert.ToInt32(cmdInsertGroup.ExecuteScalar());

                    MessageBox.Show("Group created successfully!");

                    // Now, call the DisplayGroups method to update the display
                    DisplayGroups();
                } // The using statement will automatically close the connection
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }




        private void display_Click(object sender, EventArgs e)
        {
            DisplayGroups();
        }
        private void DisplayGroups()
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("SELECT * FROM [Group]", con); // Use [Group] instead of Group
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView3.DataSource = dt;

                // Auto-size DataGridView columns based on content
                dataGridView3.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                dataGridView3.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                dataGridView3.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
                dataGridView3.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                dataGridView3.DefaultCellStyle.Font = new Font("Arial", 15);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }


        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Get the selected group ID from the DataGridView
            AddGroupIdFromDataGridView(dataGridView3.SelectedCells[0].RowIndex);

            // Get the selected student IDs from the TextBox
            selectedStudentIds = GetStudentIdsFromTextBox();

            // Add students to the group
            AddStudentsToGroup(selectedGroupId, selectedStudentIds);
        }


        private void button2_Click(object sender, EventArgs e)
        {
            DisplayGroups();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from GroupStudent", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView3.DataSource = dt;

            // Adjust DataGridView properties
            dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView3.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView3.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridView3.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView3.DefaultCellStyle.Font = new Font("Arial", 15);
        }

        private int GetStatusId(string statusValue)
        {
            try
            {
                // Query to retrieve the ID of the status from the Lookup table
                string query = "SELECT Id FROM Lookup WHERE Value = @StatusValue AND Category = 'STATUS'";

                SqlConnection connection = Configuration.getInstance().getConnection();
                {


                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@StatusValue", statusValue);

                    //Execute the query and retrieve the status ID
                    int statusId = (int)command.ExecuteScalar();

                    return statusId;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving status ID: " + ex.Message);
                return -1; // Return a placeholder value indicating an error
            }
        }
        private void PopulateStatusComboBox()
        {
            // Clear existing items
            comboBox1.Items.Clear();

            // Query to retrieve status values from the Lookup table
            string query = "SELECT Value FROM Lookup WHERE Category = 'STATUS'";

            using (SqlConnection connection = Configuration.getInstance().getConnection())
            {
                SqlCommand command = new SqlCommand(query, connection);

                // Open the connection explicitly
                connection.Open();

                // Execute the query to retrieve status values
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    // Add each status value to the ComboBox
                    comboBox1.Items.Add(reader["Value"].ToString());
                }
            }
        }



        private void AddStudentsToGroup(int groupId, List<int> selectedStudentIds)

        {
            try
            {
                
               int activeStatusId = GetStatusId("Active");

                SqlConnection connection = Configuration.getInstance().getConnection();
                {
                    connection.Open();

                    foreach (int studentId in selectedStudentIds)
                    {
                        
                        string insertGroupStudentQuery = "INSERT INTO GroupStudent (GroupId, StudentId, Status, AssignmentDate) VALUES (@GroupId, @StudentId, @Status, @AssignmentDate)";
                        SqlCommand cmdInsertGroupStudent = new SqlCommand(insertGroupStudentQuery, connection);
                        cmdInsertGroupStudent.Parameters.AddWithValue("@GroupId", groupId);
                        cmdInsertGroupStudent.Parameters.AddWithValue("@StudentId", studentId);

                        
                        cmdInsertGroupStudent.Parameters.AddWithValue("@Status", activeStatusId);

                       
                        cmdInsertGroupStudent.Parameters.AddWithValue("@AssignmentDate", DateTime.Now);

                        
                        cmdInsertGroupStudent.ExecuteNonQuery();
                    }

                    
                     connection.Close();

                    MessageBox.Show("Students added to group successfully!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView3.DataSource = dt;

            // Adjust DataGridView properties
            dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView3.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView3.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridView3.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView3.DefaultCellStyle.Font = new Font("Arial", 15);
        }

        private void AddGroupIdFromDataGridView(int rowIndex)
        {
            // Check if a valid row index is provided
            if (rowIndex >= 0 && rowIndex < dataGridView3.Rows.Count)
            {
                // Get the group ID from the DataGridView
                selectedGroupId = Convert.ToInt32(dataGridView3.Rows[rowIndex].Cells["Id"].Value);
                MessageBox.Show($"Selected Group ID: {selectedGroupId}");
            }
        }

        // Function to retrieve and store student IDs from a TextBox
        private List<int> GetStudentIdsFromTextBox()
        {
            string studentIdsText = textBox1.Text;
            return studentIdsText.Split(',').Select(int.Parse).ToList();
        }
        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Call the function to add group ID from the DataGridView
            AddGroupIdFromDataGridView(e.RowIndex);
        }


    }
}
    

