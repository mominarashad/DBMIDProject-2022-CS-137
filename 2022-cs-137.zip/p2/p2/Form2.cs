﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace p2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void seeData()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Person", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }
       

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            con.Close();

            try
            {
                seeData();
                using (SqlCommand sqlCommand = new SqlCommand("INSERT INTO Person (FirstName, LastName, Contact, Email, DateOfBirth, Gender) VALUES (@FirstName, @LastName, @Contact, @Email, @DateOfBirth, @Gender); INSERT INTO Student (Id, RegistrationNo) VALUES (SCOPE_IDENTITY(), @RegistrationNo);", con))
                {
                    sqlCommand.Parameters.AddWithValue("@FirstName", textBox1.Text);
                    sqlCommand.Parameters.AddWithValue("@LastName", textBox2.Text);
                    sqlCommand.Parameters.AddWithValue("@Contact", textBox3.Text);
                    sqlCommand.Parameters.AddWithValue("@Email", textBox4.Text);
                    sqlCommand.Parameters.AddWithValue("@DateOfBirth", textBox5.Text);
                    sqlCommand.Parameters.AddWithValue("@Gender", int.Parse(textBox6.Text));
                    sqlCommand.Parameters.AddWithValue("@RegistrationNo", textBox7.Text);
                    con.Open();
                    sqlCommand.ExecuteNonQuery();
                    
                    MessageBox.Show("Successfully saved");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error creating person: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    

        private void button2_Click(object sender, EventArgs e)
        {
            
                var con = Configuration.getInstance().getConnection();
                try
                {
                    using (SqlCommand sqlCommand = new SqlCommand("UPDATE Person SET FirstName = @FirstName, LastName = @LastName, Contact = @Contact, Email = @Email, DateOfBirth = @DateOfBirth, Gender = @Gender WHERE Id = @Id; UPDATE Student SET RegistrationNo = @RegistrationNo WHERE Id = @Id;", con))
                    {
                       
                        sqlCommand.Parameters.AddWithValue("@FirstName", textBox1.Text);
                        sqlCommand.Parameters.AddWithValue("@LastName", textBox2.Text);
                        sqlCommand.Parameters.AddWithValue("@Contact", textBox3.Text);
                        sqlCommand.Parameters.AddWithValue("@Email", textBox4.Text);
                        sqlCommand.Parameters.AddWithValue("@DateOfBirth", textBox5.Text);
                        sqlCommand.Parameters.AddWithValue("@Gender", int.Parse(textBox6.Text));
                        sqlCommand.Parameters.AddWithValue("@RegistrationNo", textBox7.Text);
                        sqlCommand.Parameters.AddWithValue("@Id", int.Parse(textBox8.Text));
                    con.Open();
                        sqlCommand.ExecuteNonQuery();
                        MessageBox.Show("Successfully updated");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error updating person: " + ex.Message);
                }
                finally
                {
                    con.Close();
                    seeData(); // Refresh the data grid after update
                }
            

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
           
                var con = Configuration.getInstance().getConnection();
                try
                {
                    using (SqlCommand sqlCommand = new SqlCommand("DELETE FROM Student WHERE Id = @Id; DELETE FROM Person WHERE Id = @Id;", con))
                    {
                        sqlCommand.Parameters.AddWithValue("@Id", int.Parse(textBox8.Text)); // Assuming you have a variable to store the selected person's ID
                        con.Open();
                        sqlCommand.ExecuteNonQuery();
                        MessageBox.Show("Successfully deleted");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error deleting person: " + ex.Message);
                }
                finally
                {
                    con.Close();
                    seeData(); // Refresh the data grid after delete
                }
            }

        private void button3_Click(object sender, EventArgs e)
        {
            
                var con = Configuration.getInstance().getConnection();
                try
                {
                    using (SqlCommand sqlCommand = new SqlCommand("SELECT * FROM Person WHERE FirstName LIKE @SearchKeyword OR LastName LIKE @SearchKeyword OR Email LIKE @SearchKeyword", con))
                    {
                        //sqlCommand.Parameters.AddWithValue("@SearchKeyword", "%" + searchKeyword + "%");
                        SqlDataAdapter da = new SqlDataAdapter(sqlCommand);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error searching data: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }

        }
    }
    

