﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace p2
{
    public partial class Form5 : Form
    {
        private SqlConnection con;

        List<Tuple<string, string>> StudentIds = new List<Tuple<string, string>>();
       

        public Form5()
        {
            InitializeComponent();
            getStudentids();
            getGroupids();
             con = Configuration.getInstance().getConnection();


        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void getStudentids()
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                var con2 = Configuration.getInstance().getConnection();

                using(SqlCommand command=new SqlCommand("Select Id FROM Student",con))
                {
                    using (SqlDataReader reader = command.ExecuteReader()) {
                        comboBox2.Items.Clear();
                        while (reader.Read())
                        {
                            comboBox2.Items.Add(reader["Id"].ToString());
                        }
                    }
                        
                }
                //using (SqlCommand command = new SqlCommand("Select Id FROM [Group]", con))
                //{
                //    using (SqlDataReader reader = command.ExecuteReader())
                //    {
                //        comboBox2.Items.Clear();
                //        while (reader.Read())
                //        {
                //            comboBox2.Items.Add(reader["Id"].ToString());
                //        }
                //    }

                //}

            }
            catch(Exception ex)
            {
                MessageBox.Show("Error loading ids:" + ex.Message);
            }
        }
        private void getGroupids()
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                
                using (SqlCommand command = new SqlCommand("Select Id FROM [Group]", con))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        comboBox1.Items.Clear();
                        while (reader.Read())
                        {
                            comboBox1.Items.Add(reader["Id"].ToString());
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading ids:" + ex.Message);
            }
        }
        private int CountStudents(string groupId)
        {
            int count = 0;
            try
            {
                var con = Configuration.getInstance().getConnection();
                string Querey = $"Select Count(*) FROM GroupStudent WHERE GroupId='{groupId}'";
                using (SqlCommand command = new SqlCommand(Querey, con))
                {
                    count = (int)command.ExecuteScalar();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error ");
            }
            return count;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string selectedStudentId = comboBox2.SelectedItem?.ToString();
            string selectedGroupId = comboBox1.SelectedItem?.ToString();

            // Check both ids are selected
            if (!string.IsNullOrEmpty(selectedStudentId) && !string.IsNullOrEmpty(selectedGroupId))
            {
                // Check if the student is already in an active state in any group
                if (!IsStudentActiveInAnyGroup(con, selectedStudentId))
                {
                    if (CountStudents(selectedGroupId) < 5)
                    {
                        StudentIds.Add(new Tuple<string, string>(selectedGroupId, selectedStudentId));
                        MessageBox.Show("Student Added to group Successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Group reached its max limit");
                    }
                }
                else
                {
                    MessageBox.Show("Student is already in an active state in another group.");
                }
            }
            else
            {
                MessageBox.Show("Please Add both ids");
            }
        }

        // Add a new method to check if a student is active in any group
        private bool IsStudentActiveInAnyGroup(SqlConnection connection, string studentId)
        {
            string query = "SELECT COUNT(*) FROM GroupStudent WHERE StudentId = @StudentId AND Status = @ActiveStatus";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@StudentId", studentId);
                command.Parameters.AddWithValue("@ActiveStatus", GetStatus("Active", connection)); // Assuming "Active" is the value for active status

                int count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                int StatusId = GetStatus(comboBox3.Text, con);
                foreach (var studentId in StudentIds)
                {
                    // Check if the record already exists
                    if (!IsGroupStudentExists(con, studentId.Item1, studentId.Item2))
                    {
                        // If not exists, then insert the record
                        string insertGroupStudentQuery = "INSERT INTO GroupStudent (GroupId, StudentId, Status, AssignmentDate) VALUES (@GroupId, @StudentId, @Status, @AssignmentDate)";
                        SqlCommand cmdInsertGroupStudent = new SqlCommand(insertGroupStudentQuery, con);
                        cmdInsertGroupStudent.Parameters.AddWithValue("@GroupId", studentId.Item1);
                        cmdInsertGroupStudent.Parameters.AddWithValue("@StudentId", studentId.Item2);
                        cmdInsertGroupStudent.Parameters.AddWithValue("@Status", StatusId);
                        cmdInsertGroupStudent.Parameters.AddWithValue("@AssignmentDate", DateTime.Now);
                        cmdInsertGroupStudent.ExecuteNonQuery();
                    }
                    else
                    {
                        // Handle the case where the record already exists
                        MessageBox.Show($"Record with GroupId: {studentId.Item1} and StudentId: {studentId.Item2} already exists.");
                    }
                }


                MessageBox.Show("Students added to the group successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }

        static int GetStatus(string statusValue, SqlConnection connection)
        {
            try
            {
                

                string query = "SELECT Id FROM dbo.Lookup WHERE Value = @StatusValue AND Category = 'STATUS'";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@StatusValue", statusValue);

                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        return Convert.ToInt32(result);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error getting status: " + ex.Message);
            }
            

            // Return -1 if the status is not found or an error occurs
            return -1;
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void View_Click(object sender, EventArgs e)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();


                SqlCommand cmd = new SqlCommand("SELECT * FROM [GroupStudent]", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView3.DataSource = dt;
                // The using statement will automatically close the connection
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }
        private bool IsGroupStudentExists(SqlConnection connection, string groupId, string studentId)
        {
            string query = "SELECT COUNT(*) FROM GroupStudent WHERE GroupId = @GroupId AND StudentId = @StudentId";

            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@GroupId", groupId);
                command.Parameters.AddWithValue("@StudentId", studentId);

                int count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                int StatusId = GetStatus(comboBox3.Text, con);

                // Get the GroupId to update from the TextBox
                string groupIdToUpdate = textBox1.Text.Trim();

                foreach (var studentId in StudentIds)
                {
                    // Check if the record already exists
                    if (!IsGroupStudentExists(con, studentId.Item1, studentId.Item2))
                    {
                        // If not exists, then insert the record
                        InsertGroupStudent(con, studentId.Item1, studentId.Item2, StatusId);
                    }
                    else
                    {
                        // If exists and matches the specified GroupId, update the record
                        if (studentId.Item1 == groupIdToUpdate)
                        {
                            UpdateGroupStudent(con, studentId.Item1, studentId.Item2, StatusId);
                        }
                    }
                }

                MessageBox.Show("Students added or updated in the group successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }
        private void InsertGroupStudent(SqlConnection connection, string groupId, string studentId, int statusId)
        {
            string insertGroupStudentQuery = "INSERT INTO GroupStudent (GroupId, StudentId, Status, AssignmentDate) VALUES (@GroupId, @StudentId, @Status, @AssignmentDate)";
            using (SqlCommand cmdInsertGroupStudent = new SqlCommand(insertGroupStudentQuery, connection))
            {
                cmdInsertGroupStudent.Parameters.AddWithValue("@GroupId", groupId);
                cmdInsertGroupStudent.Parameters.AddWithValue("@StudentId", studentId);
                cmdInsertGroupStudent.Parameters.AddWithValue("@Status", statusId);
                cmdInsertGroupStudent.Parameters.AddWithValue("@AssignmentDate", DateTime.Now);
                cmdInsertGroupStudent.ExecuteNonQuery();
            }
        }

        private void UpdateGroupStudent(SqlConnection connection, string groupId, string studentId, int statusId)
        {
            string updateGroupStudentQuery = "UPDATE GroupStudent SET Status = @Status, AssignmentDate = @AssignmentDate WHERE GroupId = @GroupId AND StudentId = @StudentId";
            using (SqlCommand cmdUpdateGroupStudent = new SqlCommand(updateGroupStudentQuery, connection))
            {
                cmdUpdateGroupStudent.Parameters.AddWithValue("@GroupId", groupId);
                cmdUpdateGroupStudent.Parameters.AddWithValue("@StudentId", studentId);
                cmdUpdateGroupStudent.Parameters.AddWithValue("@Status", statusId);
                cmdUpdateGroupStudent.Parameters.AddWithValue("@AssignmentDate", DateTime.Now);
                cmdUpdateGroupStudent.ExecuteNonQuery();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }


}
    

