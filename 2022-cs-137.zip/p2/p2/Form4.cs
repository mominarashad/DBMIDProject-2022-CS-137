﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace p2
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void seeData()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Project", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            // Adjust DataGridView properties
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.DefaultCellStyle.Font = new Font("Arial", 10);
        }


        private void button1_Click(object sender, EventArgs e)
        {
           
                var con = Configuration.getInstance().getConnection();

                try
                {
                    con.Open(); // Open the connection here

                    seeData(); // Assuming this is meant to display data before insertion

                    using (SqlCommand sqlCommand = new SqlCommand("INSERT INTO Project (Description,Title) VALUES (@Description,@Title);", con))
                    {
                        sqlCommand.Parameters.AddWithValue("@Description", textBox1.Text);
                        sqlCommand.Parameters.AddWithValue("@Title", textBox2.Text);

                        sqlCommand.ExecuteNonQuery();
                    }

                    MessageBox.Show("Successfully saved");
                seeData();
            }
                catch (Exception ex)
                {
                    Console.WriteLine("Error creating person: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }






        private void button2_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            con.Close();
            try
            {
                using (SqlCommand sqlCommand = new SqlCommand("UPDATE Person SET Description = @Description, Title = @Title,   WHERE Id = @Id;", con))
                {

                    sqlCommand.Parameters.AddWithValue("@Description", textBox1.Text);
                    sqlCommand.Parameters.AddWithValue("@Title", textBox2.Text);
                    con.Open();
                    sqlCommand.ExecuteNonQuery();
                    MessageBox.Show("Successfully updated");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error updating person: " + ex.Message);
            }
            finally
            {
                con.Close();
                seeData(); // Refresh the data grid after update
            }



        
    }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Assuming your DataGridView has a column named "ID" for the Project ID
                int rowIndex = dataGridView1.SelectedRows[0].Index;
                dataGridView1.Rows.RemoveAt(rowIndex);
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
    }


