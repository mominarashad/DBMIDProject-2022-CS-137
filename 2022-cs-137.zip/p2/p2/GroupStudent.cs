﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace p2
{
    public partial class GroupStudent : Form
    {
        public GroupStudent()
        {
            InitializeComponent();
            PopulateStudentComboBox();
        }
        private int selectedGroupId = -1;
        private List<int> selectedStudentIds = new List<int>();

        private void button1_Click(object sender, EventArgs e)
        {
            string createdOn = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            // Insert the new group into the database
            InsertNewGroup(createdOn);
        }

        private void InsertNewGroup(string createdOn)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                // connection.Open();
                // Step 1: Insert data into the Group table
                string insertGroupQuery = "INSERT INTO [Group] (Created_On) VALUES (@CreatedOn); SELECT SCOPE_IDENTITY();";
                    SqlCommand cmdInsertGroup = new SqlCommand(insertGroupQuery, con);
                    cmdInsertGroup.Parameters.AddWithValue("@CreatedOn", createdOn);

                    // Retrieve the auto-generated ID of the newly inserted group
                    int newGroupId = Convert.ToInt32(cmdInsertGroup.ExecuteScalar());

                    MessageBox.Show("Group created successfully!");
                    

                    
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }

        private void DisplayGroups()
        {
            try
            {
                var con = Configuration.getInstance().getConnection();


                SqlCommand cmd = new SqlCommand("SELECT * FROM [Group]", con);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView3.DataSource = dt;
                 // The using statement will automatically close the connection
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }




        private void button2_Click(object sender, EventArgs e)
        {
            DisplayGroups();
        }

        private void GroupStudent_Load(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from [Student]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView3.DataSource = dt;
           // con.Close();
        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Call the function to add group ID from the DataGridView
            
        }

        //private void AddGroupIdFromDataGridView(int rowIndex)
        //{
        //    // Check if a valid row index is provided
        //    if (rowIndex >= 0 && rowIndex < dataGridView3.Rows.Count)
        //    {
        //        // Get the group ID from the DataGridView
        //        selectedGroupId = Convert.ToInt32(dataGridView3.Rows[rowIndex].Cells["Id"].Value);
        //        MessageBox.Show($"Selected Group ID: {selectedGroupId}");
        //    }
        //}

        private void PopulateStudentComboBox()
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                string selectStudentQuery = "SELECT Id FROM [Student]";
                    SqlCommand cmdSelectStudent = new SqlCommand(selectStudentQuery, con);
                    SqlDataReader reader = cmdSelectStudent.ExecuteReader();

                    // Clear existing items in the ComboBox
                    comboBox1.Items.Clear();

                    while (reader.Read())
                    {
                        int studentId = Convert.ToInt32(reader["Id"]);
                        comboBox1.Items.Add(studentId);
                    }

                    reader.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while populating ComboBox: " + ex.Message);
            }
        }

        private void SaveSelectedStudentIds()
        {
            if (comboBox1.SelectedItem != null)
            {
                selectedStudentIds.Add(Convert.ToInt32(comboBox1.SelectedItem));
            }

            // Clear the ComboBox for the next use
            comboBox1.SelectedItem = null;
        }

        private int GetStatusId(string statusValue)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                //connection.Open(); // Open the connection explicitly

                // Query to retrieve the ID of the status from the Lookup table
                string query = "SELECT Id FROM Lookup WHERE Value = @StatusValue AND Category = 'STATUS'";

                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        command.Parameters.AddWithValue("@StatusValue", statusValue);

                        // Execute the query and retrieve the status ID
                        int statusId = (int)command.ExecuteScalar();

                        return statusId;
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while retrieving status ID: " + ex.Message);
                return -1; // Return a placeholder value indicating an error
            }
        }

        private void PopulateStatusComboBox()
        {
            // Clear existing items
            comboBox2.Items.Clear();

            // Query to retrieve status values from the Lookup table
            string query = "SELECT Value FROM Lookup WHERE Category = 'STATUS'";

            var con = Configuration.getInstance().getConnection();
            SqlCommand command = new SqlCommand(query, con);

                // Open the connection explicitly
               // connection.Open();

                // Execute the query to retrieve status values
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    // Add each status value to the ComboBox
                    comboBox2.Items.Add(reader["Value"].ToString());
                }
            
        }

        //private void AddStudentsToGroup(int groupId, List<int> studentIds, int statusId)
        //{
        //    try
        //    {
        //        SqlConnection connection = Configuration.getInstance().getConnection();
               
        //        foreach (int studentId in studentIds)
        //        {
        //            string insertGroupStudentQuery = "INSERT INTO GroupStudent (GroupId, StudentId, Status, AssignmentDate) VALUES (@GroupId, @StudentId, @Status, @AssignmentDate)";
        //            SqlCommand cmdInsertGroupStudent = new SqlCommand(insertGroupStudentQuery, connection);
        //            cmdInsertGroupStudent.Parameters.AddWithValue("@GroupId", groupId);
        //            cmdInsertGroupStudent.Parameters.AddWithValue("@StudentId", studentId);
        //            cmdInsertGroupStudent.Parameters.AddWithValue("@Status", statusId);
        //            cmdInsertGroupStudent.Parameters.AddWithValue("@AssignmentDate", DateTime.Now);
        //            cmdInsertGroupStudent.ExecuteNonQuery();
        //        }

        //        MessageBox.Show("Students added to group successfully.");
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error occurred: " + ex.Message);
        //    }
        //}

        private void button3_Click(object sender, EventArgs e)
        {
            SaveSelectedStudentIds();
            GetSelectedGroupId();

            // Get the status ID from the selected status in the ComboBox
            string selectedStatus = comboBox2.SelectedItem.ToString();
            int statusId = GetStatusId(selectedStatus);

            // Add students to the group using the selected group ID, selected student IDs, and status ID
            AddStudentsToGroup(selectedGroupId, selectedStudentIds, statusId); 
        }
        private int GetSelectedGroupId()
        {
            if (dataGridView3.SelectedRows.Count > 0)
            {
                MessageBox.Show("Group Selected");
                return (int)dataGridView3.SelectedRows[0].Cells["Id"].Value;
            }
            else
            {
                MessageBox.Show("Please select a group.");
                return -1;
            }
        }


        private void AddStudentsToGroup(int groupId, List<int> studentIds, int statusId)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();

                foreach (int studentId in studentIds)
                {
                    string insertGroupStudentQuery = "INSERT INTO GroupStudent (GroupId, StudentId, Status, AssignmentDate) VALUES (@GroupId, @StudentId, @Status, @AssignmentDate)";
                    SqlCommand cmdInsertGroupStudent = new SqlCommand(insertGroupStudentQuery, con);
                    cmdInsertGroupStudent.Parameters.AddWithValue("@GroupId", groupId);  // Ensure this groupId exists in the Group table
                    cmdInsertGroupStudent.Parameters.AddWithValue("@StudentId", studentId);
                    cmdInsertGroupStudent.Parameters.AddWithValue("@Status", statusId);
                    cmdInsertGroupStudent.Parameters.AddWithValue("@AssignmentDate", DateTime.Now);
                    cmdInsertGroupStudent.ExecuteNonQuery();
                }

                MessageBox.Show("Students added to the group successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
