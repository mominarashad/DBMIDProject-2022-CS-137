﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace p2
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        private void seeData()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from GroupProject", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            // Adjust DataGridView properties
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.DefaultCellStyle.Font = new Font("Arial", 10);
        }
        private void button1_Click(object sender, EventArgs e)
        {

            var con = Configuration.getInstance().getConnection();

            try
            {
                con.Open(); // Open the connection here

                seeData(); // Assuming this is meant to display data before insertion

                using (SqlCommand sqlCommand = new SqlCommand("INSERT INTO GroupProject (Description,Title) VALUES (@Description,@Title);", con))
                {
                   // sqlCommand.Parameters.AddWithValue("@Description", textBox1.Text);
                    //sqlCommand.Parameters.AddWithValue("@Title", textBox2.Text);

                    sqlCommand.ExecuteNonQuery();
                }

                MessageBox.Show("Successfully saved");
                seeData();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error creating person: " + ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }
    }
}
