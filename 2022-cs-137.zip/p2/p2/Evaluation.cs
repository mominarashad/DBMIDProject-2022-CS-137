﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace p2
{
    public partial class Evaluation : Form
    {
        
        public Evaluation()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            try
            {
               

                using (SqlCommand sqlCommand = new SqlCommand("INSERT INTO [Evaluation] ( Name, TotalMarks, TotalWeightage) VALUES ( @Name, @TotalMarks, @TotalWeightage);", con))
                {
                    
                    sqlCommand.Parameters.AddWithValue("@Name", textBox2.Text);
                    sqlCommand.Parameters.AddWithValue("@TotalMarks", int.Parse(textBox3.Text));
                    sqlCommand.Parameters.AddWithValue("@TotalWeightage", int.Parse(textBox4.Text));

                    sqlCommand.ExecuteNonQuery();

                    MessageBox.Show("Successfully saved");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error creating person: " + ex.Message);
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();


                SqlCommand cmd = new SqlCommand("SELECT * FROM [Evaluation]", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                // The using statement will automatically close the connection
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }
        public void CreateEvaluation(string name, int totalMarks, int totalWeightage)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            try
            {


                using (SqlCommand sqlCommand = new SqlCommand("UPDATE Evaluation SET Name = @Name, TotalMarks = @TotalMarks, TotalWeightage = @TotalWeightage WHERE Id = @Id;", con))
                {
                    sqlCommand.Parameters.AddWithValue("@Id", int.Parse(textBox1.Text));
                    sqlCommand.Parameters.AddWithValue("@Name", textBox2.Text);
                    sqlCommand.Parameters.AddWithValue("@TotalMarks", int.Parse(textBox3.Text));
                    sqlCommand.Parameters.AddWithValue("@TotalWeightage", int.Parse(textBox4.Text));

                    sqlCommand.ExecuteNonQuery();

                    MessageBox.Show("Successfully saved");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error creating person: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SearchEvaluations(textBox1.Text);
        }

        public DataTable SearchEvaluations(string searchTerm)
        {
            var con = Configuration.getInstance().getConnection();
            try
            {
                using (SqlCommand sqlCommand = new SqlCommand("SELECT * FROM [Evaluation] WHERE [Name] LIKE @SearchTerm;", con))
                {
                    sqlCommand.Parameters.AddWithValue("@SearchTerm", "%" + textBox1.Text + "%");

                    SqlDataAdapter da = new SqlDataAdapter(sqlCommand);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    return dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error searching evaluations: " + ex.Message);
                return null;
            }
        }


    }


}

    

