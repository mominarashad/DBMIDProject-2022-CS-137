﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace p2
{
    public partial class Advisor : Form
    {
        public Advisor()
        {
            InitializeComponent();
        }

        private void seeData()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Person", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                string getGenderIdQuery = "SELECT Id FROM Lookup WHERE Value = @Gender AND Category = 'GENDER'";
                SqlCommand cmdGetGenderId = new SqlCommand(getGenderIdQuery, con);
                cmdGetGenderId.Parameters.AddWithValue("@Gender", comboBox1.Text);
                int GenderId = Convert.ToInt32(cmdGetGenderId.ExecuteScalar());



                string getDesignationIdQuery = "SELECT Id FROM Lookup WHERE Value = @Designation AND Category = 'DESIGNATION'";
                SqlCommand cmdGetDesignationId = new SqlCommand(getDesignationIdQuery, con);
                cmdGetDesignationId.Parameters.AddWithValue("@Designation", comboBox2.Text);
                int DesignationId = Convert.ToInt32(cmdGetDesignationId.ExecuteScalar());





                // int genderId = Convert.ToInt32(cmdGetGenderId.ExecuteScalar());

                string insertPersonQuery = @"INSERT INTO Person (FirstName, LastName, Contact, Email, DateOfBirth, Gender)
                             VALUES (@FirstName, @LastName, @Contact, @Email, @DateOfBirth, @Gender);
                             SELECT SCOPE_IDENTITY();";
                SqlCommand cmdInsertPerson = new SqlCommand(insertPersonQuery, con);
                cmdInsertPerson.Parameters.AddWithValue("@FirstName", textBox1.Text);
                cmdInsertPerson.Parameters.AddWithValue("@LastName", textBox5.Text);
                cmdInsertPerson.Parameters.AddWithValue("@Contact", textBox6.Text);
                cmdInsertPerson.Parameters.AddWithValue("@Email", textBox4.Text);
                cmdInsertPerson.Parameters.AddWithValue("@DateOfBirth", DateTime.Parse(textBox2.Text));
                cmdInsertPerson.Parameters.AddWithValue("@Gender", GenderId);

                int newPersonId = Convert.ToInt32(cmdInsertPerson.ExecuteScalar());

                string insertAdvisorQuery = "INSERT INTO Advisor (Id, Salary, Designation) VALUES (@Id, @Salary, @Designation)";
                SqlCommand cmdInsertAdvisor = new SqlCommand(insertAdvisorQuery, con);
                cmdInsertAdvisor.Parameters.AddWithValue("@Id", newPersonId);
                cmdInsertAdvisor.Parameters.AddWithValue("@Salary", decimal.Parse(textBox3.Text));
                cmdInsertAdvisor.Parameters.AddWithValue("@Designation", DesignationId);

                cmdInsertAdvisor.ExecuteNonQuery();

                MessageBox.Show("Advisor added successfully.");
                seeData();
                // DisplayAdvisorsData();
                // ClearTextBoxes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
                try
                {
                    var con = Configuration.getInstance().getConnection();

                    // Get Gender Id
                    string getGenderIdQuery = "SELECT Id FROM Lookup WHERE Value = @Gender AND Category = 'GENDER'";
                    SqlCommand cmdGetGenderId = new SqlCommand(getGenderIdQuery, con);
                    cmdGetGenderId.Parameters.AddWithValue("@Gender", comboBox1.Text);
                    int GenderId = Convert.ToInt32(cmdGetGenderId.ExecuteScalar());

                    // Get Designation Id
                    string getDesignationIdQuery = "SELECT Id FROM Lookup WHERE Value = @Designation AND Category = 'DESIGNATION'";
                    SqlCommand cmdGetDesignationId = new SqlCommand(getDesignationIdQuery, con);
                    cmdGetDesignationId.Parameters.AddWithValue("@Designation", comboBox2.Text);
                    int DesignationId = Convert.ToInt32(cmdGetDesignationId.ExecuteScalar());

                    // Update Person table
                    string updatePersonQuery = @"UPDATE Person SET FirstName = @FirstName, LastName = @LastName,
                                     Contact = @Contact, Email = @Email, DateOfBirth = @DateOfBirth, Gender = @Gender
                                     WHERE Id = @Id";
                    SqlCommand cmdUpdatePerson = new SqlCommand(updatePersonQuery, con);
                    cmdUpdatePerson.Parameters.AddWithValue("@Id", textBox7.Text);
                    cmdUpdatePerson.Parameters.AddWithValue("@FirstName", textBox1.Text);
                    cmdUpdatePerson.Parameters.AddWithValue("@LastName", textBox5.Text);
                    cmdUpdatePerson.Parameters.AddWithValue("@Contact", textBox6.Text);
                    cmdUpdatePerson.Parameters.AddWithValue("@Email", textBox4.Text);
                    cmdUpdatePerson.Parameters.AddWithValue("@DateOfBirth", DateTime.Parse(textBox2.Text));
                    cmdUpdatePerson.Parameters.AddWithValue("@Gender", GenderId);

                    cmdUpdatePerson.ExecuteNonQuery();

                    // Update Advisor table
                    string updateAdvisorQuery = "UPDATE Advisor SET Salary = @Salary, Designation = @Designation WHERE Id = @Id";
                    SqlCommand cmdUpdateAdvisor = new SqlCommand(updateAdvisorQuery, con);
                    cmdUpdateAdvisor.Parameters.AddWithValue("@Id", textBox7.Text);
                    cmdUpdateAdvisor.Parameters.AddWithValue("@Salary", decimal.Parse(textBox3.Text));
                    cmdUpdateAdvisor.Parameters.AddWithValue("@Designation", DesignationId);

                    cmdUpdateAdvisor.ExecuteNonQuery();

                    MessageBox.Show("Advisor updated successfully.");
                    seeData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred: " + ex.Message);
                }
            }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();

                // Search for the given ID in Person table
                string searchPersonQuery = "SELECT * FROM Person WHERE Id = @Id";
                SqlCommand cmdSearchPerson = new SqlCommand(searchPersonQuery, con);
                cmdSearchPerson.Parameters.AddWithValue("@Id", textBox7.Text);

                SqlDataReader reader = cmdSearchPerson.ExecuteReader();

                if (reader.HasRows)
                {
                    reader.Close();
                    MessageBox.Show("ID found. You can proceed with the update.");
                }
                else
                {
                    reader.Close();
                    MessageBox.Show("ID not found. Please enter a valid ID.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }

        private void Advisor_Load(object sender, EventArgs e)
        {

        }
    }

    }
    

