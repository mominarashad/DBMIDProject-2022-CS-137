﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace p2
{
    public partial class GroupEvalution : Form
    {
        public GroupEvalution()
        {
            InitializeComponent();
            LoadEvaluationIDs();
            LoadGroupIDs();
        }

        private void GroupEvalution_Load(object sender, EventArgs e)
        {

        }
        private void LoadGroupIDs()
        {
            var con = Configuration.getInstance().getConnection();
            string selectProjectIDsQuery = "SELECT Id FROM [Group] ";
            SqlCommand cmdSelectProjectIDs = new SqlCommand(selectProjectIDsQuery, con);
            SqlDataReader reader = cmdSelectProjectIDs.ExecuteReader();

            // Clear existing items in the ComboBox
            comboBoxproject.Items.Clear();
            //searchbox.Items.Clear();

            // Add each project ID to the ComboBox
            while (reader.Read())
            {
                comboBoxproject.Items.Add(reader["Id"].ToString());
                // searchbox.Items.Add(reader["Id"].ToString());

            }

            // Close the reader
            reader.Close();
        }

        private void LoadEvaluationIDs()
        {
            var con = Configuration.getInstance().getConnection();
            string selectAdvisorIDsQuery = "SELECT Id FROM  Evaluation";
            SqlCommand cmdSelectAdvisorIDs = new SqlCommand(selectAdvisorIDsQuery, con);
            SqlDataReader reader = cmdSelectAdvisorIDs.ExecuteReader();

            // Clear existing items in the ComboBox
            comboBoxadvisor.Items.Clear();

            // Add each advisor ID to the ComboBox
            while (reader.Read())
            {
                comboBoxadvisor.Items.Add(reader["Id"].ToString());
            }

            // Close the reader
            reader.Close();
        }

        private void assign_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            // Retrieve selected values from ComboBoxes
            int groupID = Convert.ToInt32(comboBoxproject.SelectedItem);
            int evaluationID = Convert.ToInt32(comboBoxadvisor.SelectedItem);

            try
            {
                // Check if the group has already been evaluated
                if (IsGroupEvaluated(groupID))
                {
                    MessageBox.Show("This group has already been evaluated. Cannot add another evaluation.");
                    return;
                }

                string insertGroupEvaluationQuery = "INSERT INTO GroupEvaluation (GroupId, EvaluationId, ObtainedMarks, EvaluationDate) VALUES (@GroupId, @EvaluationId, @ObtainedMarks, @EvaluationDate)";
                SqlCommand cmdInsertGroupEvaluation = new SqlCommand(insertGroupEvaluationQuery, con);
                cmdInsertGroupEvaluation.Parameters.AddWithValue("@GroupId", groupID);
                cmdInsertGroupEvaluation.Parameters.AddWithValue("@EvaluationId", evaluationID);
                cmdInsertGroupEvaluation.Parameters.AddWithValue("@ObtainedMarks", textBox2.Text);
                cmdInsertGroupEvaluation.Parameters.AddWithValue("@EvaluationDate", DateTime.Now);

                // Execute the query
                cmdInsertGroupEvaluation.ExecuteNonQuery();

                MessageBox.Show("Evaluation Marks added successfully!");
                displaydata();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }

        // Check if the group has already been evaluated
        private bool IsGroupEvaluated(int groupId)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();

                string selectQuery = "SELECT COUNT(*) FROM GroupEvaluation WHERE GroupId = @GroupId";
                SqlCommand cmdSelect = new SqlCommand(selectQuery, con);
                cmdSelect.Parameters.AddWithValue("@GroupId", groupId);

                int evaluationCount = Convert.ToInt32(cmdSelect.ExecuteScalar());

                // If there is at least one evaluation, return true (group has been evaluated)
                return evaluationCount > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while checking if the group is evaluated: " + ex.Message);
                return false; // Return false in case of an error
            }
        }


        private void displaydata()
        {
            try
            {
                var con = Configuration.getInstance().getConnection();


                SqlCommand cmd = new SqlCommand("SELECT * FROM [GroupEvaluation]", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView3.DataSource = dt;
                // The using statement will automatically close the connection
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred: " + ex.Message);
            }
        }

        private void View_Click(object sender, EventArgs e)
        {
            displaydata();
        }


    }
}
